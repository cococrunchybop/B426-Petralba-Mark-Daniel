package com.joysistvi.recordingapp.main.repository;

import com.joysistvi.recordingapp.main.model.Artist;

import java.util.List;

public interface ArtistRepository {

    List<Artist> findAllActive();

    boolean save(Artist artist);

}
