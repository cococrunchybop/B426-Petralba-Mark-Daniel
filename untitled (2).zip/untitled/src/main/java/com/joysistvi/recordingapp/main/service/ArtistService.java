package com.joysistvi.recordingapp.main.service;

import com.joysistvi.recordingapp.main.model.Artist;

import java.util.List;

public interface ArtistService {

    List<Artist> getAllActiveArtists();

    boolean createArtist(String name);

}
