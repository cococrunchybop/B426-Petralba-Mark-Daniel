package com.joysistvi.recordingapp.main;

import com.joysistvi.recordingapp.main.config.DbConnection;
import com.joysistvi.recordingapp.main.repository.ArtistRepository;
import com.joysistvi.recordingapp.main.repository.ArtistRepositoryImpl;
import com.joysistvi.recordingapp.main.service.ArtistService;
import com.joysistvi.recordingapp.main.service.ArtistServiceImpl;
import com.joysistvi.recordingapp.main.view.ArtistView;

public class App {

    public static void main(String[] args) {

        DbConnection dbConnection = new DbConnection();

        ArtistRepository artistRepository = new ArtistRepositoryImpl(dbConnection);
        ArtistService artistService = new ArtistServiceImpl(artistRepository);
        ArtistView artistView = new ArtistView(artistService);

        artistView.displayAllArtists();
        artistView.promptCreateArtist();

    }
}
