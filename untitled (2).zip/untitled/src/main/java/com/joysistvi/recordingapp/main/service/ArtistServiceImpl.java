package com.joysistvi.recordingapp.main.service;

import com.joysistvi.recordingapp.main.model.Artist;
import com.joysistvi.recordingapp.main.repository.ArtistRepository;

import java.util.List;

public class ArtistServiceImpl implements ArtistService {

    private final ArtistRepository artistRepository;

    public ArtistServiceImpl(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public List<Artist> getAllActiveArtists() {
        return artistRepository.findAllActive();
    }

    @Override
    public boolean createArtist(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Artist name is required.");
        }

        return artistRepository.save(new Artist(name.trim()));
    }


}
